open the ps668_HW1.html file on any browser
enter positive number in the text box
click the button
and a table should print out under the button
if you enter a string or a negative number, you should get an alert saying "Invalid input."