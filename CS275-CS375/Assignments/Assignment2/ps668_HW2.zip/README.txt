open the ps668_HW2.html file on any browser, make sure you're connected to the internet.
Enter your API key in the first text box, there should be a key there by default too, that's my key, you can use my key to make the requests too.
Enter the zipcode in the second textbox, default zipcode in the text box should be 19104.
click the button
and a table should print out under the button
If you enter an invalid API key or zipcode, there should be a message printed under the button saying "Error fetching url ..."