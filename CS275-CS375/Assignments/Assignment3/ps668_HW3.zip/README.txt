type in node server.js in the console
the server should start running, then open localhost:8080/ps668_HW3.html on your browser
a page should open with the heading of Assignment 3
enter the number, and select sum or factorial from the drop-down menu, then click the button
It should print the result.
On entering a negative number or any other invalid input, the webpage should give an alert saying, "Invalid input."