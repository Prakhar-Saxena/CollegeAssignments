run the server with node
then go to localhost:8080/index.html on any browser
you should see the homepage
then click on a link/button on the top left corner of the page
it should open a side panel with menu items, including home, calculator and weather
select anyone
for calculator, enter the number, and select sum or factorial from the drop-down menu, then click the button
it should print the result
on entering a negative number or any other invalid input, the webpage should give an alert saying, "Invalid input."
for weather, enter the zipcode, for this one you won't need an api key
click the button
and a table should print out under the button
if you enter an invalid zipcode, there should be an error message printed under the button saying "The zipcode is invalid."
click on home if f you want to go back to home