run the server with node
then go to localhost:8080/index.html on any browser
you should see the homepage
then click on a link/button on the top left corner of the page
it should open a side panel with menu items, including home, calculator and weather
select anyone
for table, select from the drop-down menu, then click the button
and a table should print out under the button
for transcript, select from the drop-down menu, then click the button, i have the values in html stored as the student Id's so it might not work on your system
and a table should print out under the button
