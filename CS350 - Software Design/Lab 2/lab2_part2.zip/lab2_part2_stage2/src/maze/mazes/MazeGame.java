import maze.*;

public interface MazeGame {
    public Maze createMaze(MazeFactory mazeFactory);
}
