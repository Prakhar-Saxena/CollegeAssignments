package redMaze;

import maze.Wall;

import java.awt.*;

public class RedWall extends Wall {
    @Override
    public Color getColor(){
        return Color.RED;
    }
}
