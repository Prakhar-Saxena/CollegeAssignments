import Menu.*;

public class Main {
    public static void main(String[] args){

        Menu1 menu1 = new Menu1();
//        while (true)
        menu1.executeMenu();
//        Integer[] acceptableInput = {1,2,3};
//
//        IO.Output.printString("1) SurveyTest.Survey");
//        IO.Output.printString("2) SurveyTest.Test");
//        IO.Output.printString("3) Quit");
//
//
//        Scanner in = new Scanner(System.in);
//        int input = IO.Input.getInputInteger();
//
//        while (true){//!Arrays.asList(acceptableInput).contains(i)){
//            if (Arrays.asList(acceptableInput).contains(input)) {
//                break;
//            }
//            else{
//                IO.Output.printString("Select Again");
//            }
//            IO.Output.printString("1) SurveyTest.Survey");
//            IO.Output.printString("2) SurveyTest.Test");
//            IO.Output.printString("3) Quit");
////            input = in.nextInt();
//           input = IO.Input.getInputInteger();
//
//        }
//
//        switch (input){
//            case 1:
//                IO.Output.printString("SurveyTest.Survey()");
//                Menu.SurveyMenu2 surveyMenu = new Menu.SurveyMenu2();
//                break;
//            case 2:
//                IO.Output.printString("SurveyTest.Test()");
//                break;
//            case 3:
//                IO.Output.printString("Goodbye.");
//                System.exit(0);
//            default:
//                IO.Output.printString("BOI");
//        }


    }
}
