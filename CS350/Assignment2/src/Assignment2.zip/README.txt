I am using Serialising for saving and loading files.
My Sample files are in ./Surveys/ and ./Test/
These directories are in the same directory as src/
No issues, should work as intended.. or not that I know of..