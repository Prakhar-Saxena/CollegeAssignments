package blueMaze;

import maze.Wall;

import java.awt.*;

public class BlueWall extends Wall {
    @Override
    public Color getColor(){
        return Color.BLUE;
    }
}