Hi,

I tried to replicate the input and output example given in pdf.

To give different Machine code instructions, please make changes to the "binary.txt"

To run the program run it with python3:

python3 disassembler.py

or just enter "make"

Thanks