#!/usr/bin/env python



# general info
VERSION = 1.0
# TODO: perhaps also platform info?


# graphics
screen_width  = 800
screen_height = 600
flags = None # not used at the moment, or better each option seperate?
frames_per_sec = 30


# needed by gamelogic in Multigame and Singlegame
single_player = True
# TODO: these two must be set in Multivote or in Singleoptions
players = [] # [player]
world = None

